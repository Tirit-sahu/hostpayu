<footer>
    <p>2013 © FLATY Admin Template.</p>
    </footer>