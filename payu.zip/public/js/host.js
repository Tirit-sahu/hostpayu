
$(function() {
    
    var hostid = document.getElementById("hostingsHelper").getAttribute("hosting-id");
        $.ajax({
        type:"GET",
        url:"http://localhost/payu/hostings/validation?hostid="+hostid,
        success:function(res){
        var xtirit = JSON.parse(res);
        console.log(xtirit);
        if(xtirit['expire']){
                $(".hostingsHelper").append('<div class="modal fade" id="hostingsHelperModal" role="dialog"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <h4 class="modal-title text-danger"><strong>'+xtirit['message']+'<strong></h4> </div> <div class="modal-body"> <h4><strong>Renew your expired panel before you lose them.</strong></h4> </div> <div class="modal-footer"> <a href="http://localhost/payu/payment?id='+hostid+'" class="btn btn-success">Renew</a> </div> </div> </div> </div>');
                $("#hostingsHelperModal").modal({
                backdrop: 'static',
                keyboard: false
                });
        }else{
            $(".hostingsHelper").append('<div class="modal fade" id="hostingsHelperModal" role="dialog"> <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal">&times;</button> <h4 class="modal-title">'+xtirit['message']+'</h4> </div> <div class="modal-body"> <h4><strong>Renew your panel before you lose them.</strong></h4> </div> <div class="modal-footer"> <a href="http://localhost/payu/payment?id='+hostid+'" class="btn btn-success">Renew</a> </div> </div> </div> </div>');
            $("#hostingsHelperModal").modal({
            backdrop: 'static',
            keyboard: false
            });
        }
        

        }
        }); 
});
