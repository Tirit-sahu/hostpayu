<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Anand\LaravelPaytmWallet\Facades\PaytmWallet;
use App\Models\Paytm;
use DB;

class PaytmController extends Controller
{
    // display a form for payment
    public function initiate(Request $request)
    {   
        $hosting = DB::table('hostings')->where('id', $request->id)->first();
        return view('paytm', ['hosting'=>$hosting]);
    }

    public function pay(Request $request)
    {
        date_default_timezone_set('Asia/Kolkata');
        $date = date('Y-m-d');
        $digits = 12;
        $random = rand(pow(10, $digits-1), pow(10, $digits)-1);
        // $amount = 15; //Amount to be paid

        $request->validate([
            'order_id' => 'required',
            'name' => 'required',
            'mobile' => 'required|digits:10',
            'email' => 'required|email',
            'renewal_amount' => 'required'
        ],
        [
            'order_id.required' => 'ORDER ID IS REQUIRED'
        ]
        );

        $userData = [
            'name' => $request->name, // Name of user
            'mobile' => $request->mobile, //Mobile number of user
            'email' => $request->email, //Email of user
            'fee' => $request->renewal_amount,
            'order_id' => $request->order_id."_".$random, //Order id
            'date' => $date
        ];
        dd($userData);
        $paytmuser = Paytm::create($userData); // creates a new database record

        $payment = PaytmWallet::with('receive');

        $payment->prepare([
            'order' => $userData['order_id'], 
            'user' => $paytmuser->id,
            'mobile_number' => $userData['mobile'],
            'email' => $userData['email'], // your user email address
            'amount' => $userData['fee'], // amount will be paid in INR.
            'callback_url' => route('status') // callback URL
        ]);
        return $payment->receive();  // initiate a new payment
    }

    public function paymentCallback()
    {
        $transaction = PaytmWallet::with('receive');

        $response = $transaction->response();
        dd($response);
        $order_id = $transaction->getOrderId(); // return a order id
        
        $transaction->getTransactionId(); // return a transaction id
    
        // update the db data as per result from api call
        if ($transaction->isSuccessful()) {
            Paytm::where('order_id', $order_id)->update(['status' => 1, 'transaction_id' => $transaction->getTransactionId()]);
            return redirect(route('initiate.payment'))->with('message', "Your payment is successfull.");

        } else if ($transaction->isFailed()) {
            Paytm::where('order_id', $order_id)->update(['status' => 0, 'transaction_id' => $transaction->getTransactionId()]);
            return redirect(route('initiate.payment'))->with('message', "Your payment is failed.");
            
        } else if ($transaction->isOpen()) {
            Paytm::where('order_id', $order_id)->update(['status' => 2, 'transaction_id' => $transaction->getTransactionId()]);
            return redirect(route('initiate.payment'))->with('message', "Your payment is processing.");
        }
        $transaction->getResponseMessage(); //Get Response Message If Available
        
        // $transaction->getOrderId(); // Get order id
    }
}
